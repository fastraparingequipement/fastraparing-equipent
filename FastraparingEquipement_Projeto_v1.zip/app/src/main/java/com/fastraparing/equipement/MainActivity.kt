package com.fastraparing.equipement

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FastraparingApp() }
    }
}

private fun mt(value: Double): String =
    NumberFormat.getNumberInstance(Locale("pt", "MZ")).format(value) + " MT"

@Composable
fun FastraparingApp() {
    var screen by remember { mutableStateOf("Início") }
    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Fastraparing Equipement", fontWeight = FontWeight.Bold) }) },
            bottomBar = {
                NavigationBar {
                    listOf("Início", "Cotação", "Factura", "Recibo", "Histórico").forEach { item ->
                        NavigationBarItem(
                            selected = screen == item,
                            onClick = { screen = item },
                            icon = {},
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (screen) {
                    "Cotação" -> DocumentScreen("Nova Cotação", "Cotação nº 124")
                    "Factura" -> DocumentScreen("Nova Factura", "Factura nº 112")
                    "Recibo" -> DocumentScreen("Novo Recibo", "Recibo")
                    "Histórico" -> HistoryScreen()
                    else -> HomeScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen() {
    Column(Modifier.padding(20.dp)) {
        Text("Fastraparing Equipement", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Gestão de cotações, facturas e recibos")
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("IVA padrão: 16%", fontWeight = FontWeight.Bold)
                Text("Moeda: Metical (MT)")
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Próximos módulos: geração de PDF, impressão/partilha e histórico persistente.")
    }
}

@Composable
fun DocumentScreen(title: String, number: String) {
    var subtotalText by remember { mutableStateOf("0") }
    val subtotal = subtotalText.replace(",", ".").toDoubleOrNull() ?: 0.0
    val iva = subtotal * 0.16
    val total = subtotal + iva

    LazyColumn(Modifier.padding(20.dp)) {
        item {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(number)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = subtotalText,
                onValueChange = { subtotalText = it },
                label = { Text("Subtotal (MT)") },
                singleLine = true
            )
            Spacer(Modifier.height(16.dp))
            Text("Subtotal: ${mt(subtotal)}")
            Text("IVA 16%: ${mt(iva)}")
            Text("Total a pagar: ${mt(total)}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            Button(onClick = {}) { Text("Guardar documento") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {}) { Text("Gerar PDF") }
        }
    }
}

@Composable
fun HistoryScreen() {
    Column(Modifier.padding(20.dp)) {
        Text("Histórico", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Ainda não existem documentos guardados.")
    }
}
