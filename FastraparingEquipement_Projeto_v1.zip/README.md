# Fastraparing Equipement

Projeto Android inicial da aplicação oficial da Fastraparing Equipement.

## Funções base
- Cotação
- Factura
- Recibo
- Histórico
- IVA padrão de 16%
- Moeda Metical (MT)
- Preparação para geração e partilha de PDF

## Numeração inicial
- Próxima Cotação: 124
- Próxima Factura: 112

## Compilação
O workflow do GitHub Actions gera automaticamente um APK de teste quando executado.
